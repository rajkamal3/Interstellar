package com.capgemini.bean;

public class BuyerBean {

	private Integer flatregno;
	private Integer ownerid;
	private Integer flattype;
	private Integer flatarea;
	private Integer rentamount;
	private Integer depositamount;
	
	public BuyerBean() {
		super();
	}

	public BuyerBean(Integer flatregno, Integer ownerid, Integer flattype, Integer flatarea, Integer rentamount,
			Integer depositamount) {
		super();
		this.flatregno = flatregno;
		this.ownerid = ownerid;
		this.flattype = flattype;
		this.flatarea = flatarea;
		this.rentamount = rentamount;
		this.depositamount = depositamount;
	}

	public Integer getFlatregno() {
		return flatregno;
	}

	public void setFlatregno(Integer flatregno) {
		this.flatregno = flatregno;
	}

	public Integer getOwnerid() {
		return ownerid;
	}

	public void setOwnerid(Integer ownerid) {
		this.ownerid = ownerid;
	}

	public Integer getFlattype() {
		return flattype;
	}

	public void setFlattype(Integer flattype) {
		this.flattype = flattype;
	}

	public Integer getFlatarea() {
		return flatarea;
	}

	public void setFlatarea(Integer flatarea) {
		this.flatarea = flatarea;
	}

	public Integer getRentamount() {
		return rentamount;
	}

	public void setRentamount(Integer rentamount) {
		this.rentamount = rentamount;
	}

	public Integer getDepositamount() {
		return depositamount;
	}

	public void setDepositamount(Integer depositamount) {
		this.depositamount = depositamount;
	}

	@Override
	public String toString() {
		return "BuyerBean [flatregno=" + flatregno + ", ownerid=" + ownerid + ", flattype=" + flattype + ", flatarea="
				+ flatarea + ", rentamount=" + rentamount + ", depositamount=" + depositamount + "]";
	}

	
	
}
