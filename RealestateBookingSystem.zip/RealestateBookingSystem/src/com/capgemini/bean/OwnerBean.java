package com.capgemini.bean;

public class OwnerBean {

	private String ownerid;
	private String ownername;
	private String ownerno;
	
	public OwnerBean() {
		super();
	}

	public OwnerBean(String ownerid, String ownername, String ownerno) {
		super();
		this.ownerid = ownerid;
		this.ownername = ownername;
		this.ownerno = ownerno;
	}

	public String getOwnerid() {
		return ownerid;
	}

	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	public String getOwnername() {
		return ownername;
	}

	public void setOwnername(String ownername) {
		this.ownername = ownername;
	}

	public String getOwnerno() {
		return ownerno;
	}

	public void setOwnerno(String ownerno) {
		this.ownerno = ownerno;
	}

	@Override
	public String toString() {
		return "OwnerBean [ownerid=" + ownerid + ", ownername=" + ownername + ", ownerno=" + ownerno + "]";
	}
	
}