package com.capgemini.service;

import com.capgemini.bean.BuyerBean;

public interface IFlatRegistrationService {

	public Integer buyerMethod(BuyerBean bean);
	
}
