package com.capgemini.service;

import com.capgemini.bean.BuyerBean;

public class FlatRegistrationServiceImpl implements IFlatRegistrationService{

	@Override
	public Integer buyerMethod(BuyerBean bean) {
		return null;
	}

	
	
}
