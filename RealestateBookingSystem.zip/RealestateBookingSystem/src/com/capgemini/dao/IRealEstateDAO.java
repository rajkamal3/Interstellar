package com.capgemini.dao;

public interface IRealEstateDAO {

}
