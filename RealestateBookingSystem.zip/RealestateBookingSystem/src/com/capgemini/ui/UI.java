package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.bean.BuyerBean;

public class UI {
	
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		
		BuyerBean buyer = new BuyerBean();
		
		System.out.println("1. Register Flat");
		System.out.println("2. Exit");
		
		int option = scanner.nextInt();
		
		switch(option){
		
		case 1:
			System.out.println("Enter Owner ID: 1, 2");
			Integer ownerid = scanner.nextInt();
			System.out.println("Select Flat type: 1BHK, 2BHK");
			Integer bhk = scanner.nextInt();
			System.out.println("Enter flat area in sq. feet: ");
			Integer sqfeet = scanner.nextInt();
			System.out.println("Select desired rent amount: ");
			Integer rentamount = scanner.nextInt();
			System.out.println("Enter desired deposit amount: ");
			Integer depositamount = scanner.nextInt();
			
			buyer.setOwnerid(ownerid);
			buyer.setFlattype(bhk);
			buyer.setFlatarea(sqfeet);
			buyer.setRentamount(rentamount);
			buyer.setDepositamount(depositamount);
			
			break;
			
		case 2:
			System.out.println("Thanks for using");
		
		}
		
	}
	
}
