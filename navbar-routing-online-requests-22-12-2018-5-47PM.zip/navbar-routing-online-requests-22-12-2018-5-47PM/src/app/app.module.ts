import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserfeedComponent } from './userfeed/userfeed.component';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { MessagesComponent } from './messages/messages.component';
import { SettingsComponent } from './settings/settings.component';
import { ProfileComponent } from './profile/profile.component';
import { GroupsComponent } from './groups/groups.component';
import { OnlineComponent } from './online/online.component';
import { RequestComponent } from './request/request.component';

@NgModule({
  declarations: [
    AppComponent,
    UserfeedComponent,
    HomepageComponent,
    MessagesComponent,
    SettingsComponent,
    ProfileComponent,
    GroupsComponent,
    OnlineComponent,
    RequestComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: 'profile', component: ProfileComponent },
      { path: 'userfeed', component: UserfeedComponent },
      { path: 'messages', component: MessagesComponent },
      { path: 'settings', component: SettingsComponent },
      { path: 'groups', component: GroupsComponent }
    ])
  ],
  providers: [],
  bootstrap: [
    AppComponent,
    HomepageComponent
  ]
})
export class AppModule { }
