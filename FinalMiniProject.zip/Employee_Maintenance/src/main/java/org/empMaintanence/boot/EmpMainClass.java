package org.empMaintanence.boot;

import java.util.List;
import java.util.Scanner;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.model.password;
import org.empMaintanence.service.ILoginService;
import org.empMaintanence.service.LoginServicesImpl;
import org.empMaintanence.view.UserInteraction;

public class EmpMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scanner=new Scanner(System.in);
		
		boolean flag=true;
		//CREATING REFERENCE FOR SERVICE LAYER FOR INTERACTION
		
		ILoginService loginservices=new LoginServicesImpl();
		
		UserInteraction userinteraction=new UserInteraction();
		
		UserMaster usermaster=userinteraction.getLoginDetails();
		
		if(loginservices.validlogin(usermaster)==1)
		{
			
			
	      System.out.println("--------------------------------------------VALID LOGIN!!!!--------------------------------------------------------------");	
	      System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
	      while(flag)
	      {
	    	   System.out.println("+---------------------------+");
	    	   System.out.println("|---------------------------|");
	           System.out.println("| 1.Add Employee            |");
	           System.out.println("| 2.Modify Employee details |");
	           System.out.println("| 3.Display Employees list  |");
	           System.out.println("| 4. Exit                   |");
	           System.out.println("|---------------------------|");
	           System.out.println("+---------------------------+");
	           
	           int ch=scanner.nextInt();
	           
	           if(ch==1)
	           {
	        	   Employee employee=userinteraction.addEmployeeDetails();
	                    
	        	   loginservices.addEmployeeDetails(employee);   
	           }
	           else if(ch==2)
	           {
	        	   System.out.println("+----------------------------------------+");
		    	   System.out.println("|----------------------------------------|");
	        	   System.out.println("| 1.Modify first name                    |");
	        	   System.out.println("| 2.Modify last name                     |");
	        	   System.out.println("| 3.Modify date of birth                 |");
	        	   System.out.println("| 4.Modify date of joining               |");
	        	   System.out.println("| 5.Modify department id                 |");
	        	   System.out.println("| 6.Modify employee grade                |");
	        	   System.out.println("| 7.Modify employee designation          |");
	        	   System.out.println("| 8.Modify employee basic                |");
	        	   System.out.println("| 9.Modify employee gender               |");
	        	   System.out.println("| 10.Modify employee marital status      |");
	        	   System.out.println("| 11.Modify employee home address        |");
	        	   System.out.println("| 12.Modify employee contact no          |");
	        	   System.out.println("|----------------------------------------|");
	        	   System.out.println("+----------------------------------------+");
	        	   int ch2=scanner.nextInt();
	        	   
	        	   if(ch2==1)
	        	   {
	        		   loginservices.modifyfirstname();
	        	   }
	        	   else if(ch2==2)
	        	   {
	        		   loginservices.modifyLastName();
	        	   }
	        	   else if(ch2==3)
	        	   {
	        		   loginservices.modifyDateOfBirth();
	        	   }
	        	   else if(ch2==4)
	        	   {
	        		   loginservices.modifyDateOfJoining();
	        	   }
	        	   else if(ch2==5)
	        	   {
	        		   loginservices.modifyDepartmentId();
	        	   }
	        	   else if(ch2==6)
	        	   {
	        		   loginservices.modifyEmployeeGrade();
	        	   }
	        	   else if(ch2==7)
	        	   {
	        		   loginservices.modifyDesignation();
	        	   }
	        	   else if(ch2==8)
	        	   {
	        		   loginservices.modifyBasic();
	        	   }
	        	   else if(ch2==9)
	        	   {
	        		   loginservices.modifyGender();
	        	   }
	        	   else if(ch2==10)
	        	   {
	        		   loginservices.modifyMaritalStatus();
	        	   }
	        	   else if(ch2==11)
	        	   {
	        		   loginservices.modifyHomeAddress();
	        	   }
	        	   else if(ch2==12)
	        	   {
	        		   loginservices.modifyContactNo();
	        	   }
	        	   else {
	        		   System.out.println("INVALID CHOICE");
	        	   }
	           }
	           else if(ch==3)
	           {
	        	   List<Employee> employees=loginservices.displayEmployeesList();  
	        	   
	        	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	        	   
	        	   for(Employee emp:employees)
	        	   {
	        		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	        		   System.out.println();
	        		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
	        				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	        	   }
	        	   
	           }
	           else if(ch==4)
	           {
	        	   System.exit(0);
	           }
	           else
	           {
	        	   System.out.println("Invalid choice");
	           }
	      }
	      
	      
	      
		}
		else if(loginservices.validlogin(usermaster)==2)
		{
			boolean flags=true;
			
			while(flags)
			{
			
			System.out.println("###########################  VALID EMPLOYEE #########################");
			System.out.println();
			System.out.println("+----------------------------------------+");
		    System.out.println("|----------------------------------------|");
			System.out.println("|   @@@@@@@@@    OPTIONS   @@@@@@@@      |");
			System.out.println("|----------------------------------------|");
			System.out.println("| 1.based on ----> id                    |");
			System.out.println("| 2.based on ----> first name            |");
			System.out.println("| 3.based on ----> last name             |");
			System.out.println("| 4.based on ----> department            |");
			System.out.println("| 5.based on ----> grade                 |");
			System.out.println("| 6.based on ----> marital status        |");
			System.out.println("| 7.store secure details for password    |");
			System.out.println("| 8.change password                      |");
			System.out.println("| 9.exit                                 |");
			System.out.println("|----------------------------------------|");
     	    System.out.println("+----------------------------------------+");
			
			int ch=scanner.nextInt();
			
			
			if(ch==1)
			{
   	List<Employee> employees=loginservices.findBasedOnId(usermaster.getUserId());
   	    
    
	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	   
	   for(Employee emp:employees)
	   {
		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
		   System.out.println();
		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	   }
   	
			}
			else if(ch==2)
			{
				List<Employee> employees=loginservices.findBasedOnFirstName(usermaster.getUserId());
		   	    
				 
	        	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	        	   
	        	   for(Employee emp:employees)
	        	   {
	        		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	        		   System.out.println();
	        		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
	        				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	        	   }
			   		
			}
			
			else if(ch==3)
			{
				List<Employee> employees=loginservices.findBasedOnLastName();
		   	    
				 
	        	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	        	   
	        	   for(Employee emp:employees)
	        	   {
	        		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	        		   System.out.println();
	        		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
	        				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	        	   }
			}
			else if(ch==4)
			{
				List<Employee> employees=loginservices.findBasedOnDepartment();
		   	    
				 
	        	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	        	   
	        	   for(Employee emp:employees)
	        	   {
	        		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	        		   System.out.println();
	        		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
	        				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	        	   }
			}
			else if(ch==5)
			{
				List<Employee> employees=loginservices.findBasedOnGrade();
				 
	        	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	        	   
	        	   for(Employee emp:employees)
	        	   {
	        		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	        		   System.out.println();
	        		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
	        				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	        	   }
			}
			else if(ch==6)
			{
				List<Employee> employees=loginservices.findBasedOnMaritalStatus();
		   	    
				 
	        	   System.out.println("EMPLOYEE ID\tFIRST NAME\tLAST NAME\tDATE OF BIRTH\tDATE OF JOINING\t\tEMPLOYEE DEPT ID\tGRADE\t\tDESIGNATION\tBASIC\t\tGENDER\t\tMARITAL STATUS\t\tHOME ADDRESS\t\tCONTACT NO");
	        	   
	        	   for(Employee emp:employees)
	        	   {
	        		   System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
	        		   System.out.println();
	        		   System.out.println(emp.getEmpId()+"\t\t"+emp.getEmpFirstName()+"\t\t"+emp.getEmpLastName()+"\t\t"+emp.getEmpDateOfBirth()+"\t\t"+emp.getEmpDateOfJoining()+
	        				   "\t\t"+emp.getEmpDeptId()+"\t\t"+emp.getEmpGrade()+"\t\t"+emp.getEmpDesignation()+"\t\t"+emp.getEmpBasic()+"\t\t"+emp.getEmpGender()+"\t\t"+"     "+emp.getEmpMaritalStatus()+"\t\t"+"       "+emp.getEmpHomeAddress()+"\t\t"+"      "+emp.getEmpContactNo());
	        	   }
			}
			
			else if(ch==7)
			{
				password pass=userinteraction.getSecureDetails();
				
				loginservices.storePassword(pass);
				
			}
			
			else if(ch==8)
			{
				System.out.println("ur updated password is "+loginservices.changePassword(usermaster.getUserId()));
			}
			
			else if(ch==9)
			{
				flags=false;
			}
			
			
			}
		}
		else
		{
			System.out.println("----------------------------INVALID CREDENTIALS---------------------------------");
			System.out.println("Did you FORGOT your password?????");
			password pass=userinteraction.getSecureDetails();
			
			if(loginservices.verifyPassword(pass,usermaster.getUserId())!=null)
			{
				System.out.println("This is ur password " + loginservices.verifyPassword(pass,usermaster.getUserId()));
			}
			else			
			{
				System.out.println("Your account is locked for the next 20 secs..till then u can't login");
				loginservices.lockTheAccount(usermaster.getUserId());
				
			}
		}
		
	}

}



