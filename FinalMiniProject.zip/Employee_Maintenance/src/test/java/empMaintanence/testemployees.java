package empMaintanence;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;

import org.empMaintanence.dao.LoginDaoImpl;
import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;
import org.empMaintanence.service.LoginServicesImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.cglib.core.EmitUtils;



public class testemployees {

	
	@Mock
    private LoginDaoImpl logindao;
	
	private LoginServicesImpl loginservices;
	
	
	@Before
	public void setup()
	{
		
		MockitoAnnotations.initMocks(this);
		loginservices= new LoginServicesImpl(logindao);
	}
	

	
	@Test
	public void test_acc_with_allvalid_format()
	{
	    
		
		Employee employee=new Employee();
		employee.setEmpId("100001");
		employee.setEmpFirstName("sunny");
		employee.setEmpLastName("sunny");
		employee.setEmpDateOfBirth(LocalDate.now());
		employee.setEmpDateOfJoining(LocalDate.now());
		employee.setEmpDeptId(1);
		employee.setEmpGrade("M1");
		employee.setEmpDesignation("analyst");
		employee.setEmpBasic(10000);
		employee.setEmpGender("M");
		employee.setEmpMaritalStatus("M");
		employee.setEmpHomeAddress("chennai");
		employee.setEmpContactNo("7989499127");
		
	    
	    Mockito.when(logindao.addEmployeeDetails(employee)).thenReturn(1);
	    
	    loginservices.addEmployeeDetails(employee);
	    
	    
	    Mockito.verify(logindao).addEmployeeDetails(employee);
	    
	    
	}
	
	
	@Test
	
	public void test_acc_with_alllogin_format()
	{
	   UserMaster user=new UserMaster();
	   user.setUserId("100001");
	   user.setUserName("nikhil");
	   user.setUserPassword("nnikhil@2096");
	   user.setUserType("employee");
	   
	   Mockito.when(logindao.validlogin(user)).thenReturn(2);
	   
	   loginservices.validlogin(user);
	   
	   
	   Mockito.verify(logindao).validlogin(user);
	   
	   
	}

	
}
