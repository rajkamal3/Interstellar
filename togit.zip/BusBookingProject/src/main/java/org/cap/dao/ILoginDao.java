package org.cap.dao;

import org.cap.model.BusPassRequestBean;
import org.cap.model.LoginBean;

public interface ILoginDao {
	public boolean isValidUser(LoginBean loginBean);
	public boolean addRequest(BusPassRequestBean busPassRequestBean);
}
