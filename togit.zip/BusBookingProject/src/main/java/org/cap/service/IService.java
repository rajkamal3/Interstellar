package org.cap.service;

import org.cap.model.BusPassRequestBean;
import org.cap.model.LoginBean;

public interface IService {
	
	public boolean isValidUser(LoginBean loginBean);
	public boolean addRequest(BusPassRequestBean busPassRequestBean);

}
