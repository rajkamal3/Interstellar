package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.BusPassRequestBean;
import org.cap.model.LoginBean;

public class ServiceImpl implements IService{
	
	ILoginDao dao = new LoginDaoImpl();

	@Override
	public boolean isValidUser(LoginBean loginBean) {
		
		if(dao.isValidUser(loginBean)) {
			return true;
		}
		
		return false;
	}

	@Override
	public boolean addRequest(BusPassRequestBean busPassRequestBean) {
		if(dao.addRequest(busPassRequestBean)) {
			return true;
		}
		return false;
	}
	
	
}
