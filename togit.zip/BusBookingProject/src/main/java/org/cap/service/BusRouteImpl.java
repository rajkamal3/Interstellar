package org.cap.service;

import java.util.List;

import org.cap.dao.BusRouteDaoImpl;
import org.cap.dao.IBusRouteDao;
import org.cap.model.RouteBean;

public class BusRouteImpl implements IBusRouteService{

	IBusRouteDao dao= new BusRouteDaoImpl();
	
	@Override
	public List<RouteBean> ViewRouteDetails(RouteBean routeBean) {
		List<RouteBean> routebean = dao.ViewRouteDetails(routeBean);
		return routebean;
	}

	@Override
	public boolean AddBusDetails(RouteBean routeBean) {
		if(dao.AddBusDetails(routeBean)) {
			return true;
		}
		return false;
	}


}
