package org.cap.service;

import java.util.List;

import org.cap.model.RouteBean;

public interface IBusRouteService {
	 public List<RouteBean> ViewRouteDetails(RouteBean routeBean);
	 public boolean AddBusDetails(RouteBean routeBean);
}
