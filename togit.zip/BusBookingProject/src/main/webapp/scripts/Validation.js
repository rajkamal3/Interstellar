function validate(){
	var flag=false;
	var uname = f1.userName.value;
	var upwd  = f1.userPwd.value;
	if(uname==""||uname==null){
		document.getElementById('userErrMsg').innerHTML="*Please enter a name"
			flag=false;
	} else if(upwd==""||upwd==null){
		document.getElementById('pwdErrMsg').innerHTML="*Please enter a password"
			flag=false;
	} else {
		flag=true;
	} return flag;
}