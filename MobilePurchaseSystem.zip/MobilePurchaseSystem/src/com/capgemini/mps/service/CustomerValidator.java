package com.capgemini.mps.service;

import java.util.regex.Pattern;

/**
 * @author rchenuma
 * This class validates the data fields of Customer Class 
 */
public class CustomerValidator {
	/**
	 * @param customer
	 * @return true if customerName is a series of alphabets  with one
	 *or no space,else return false
	 */
	public Boolean isValidCustomerName(String name) {
		String regex="^[A-Z]{1}[a-zA-Z\\s]{0,19}$";
		return Pattern.matches(regex, name);
	}
	
	/**
	 * @param cutomer
	 * @return true if email is valid else return false
	 * email validity:
	 * 1.email begins either with digits or alphabets followed
	 * one @ symbol followed by domain name followed by dot(.)
	 * operator followed by 2 or 3 characters followed by dot(.) operator 
	 * followed by 2 characters.
	 * The second dot operator followed by 2 characters is optional.
	 */
	public Boolean isValidEmail(String emailId) {
		//String regex="[a-zA-Z1-9._]+[@][a-zA-Z1-9]+ [.][a-zA-Z]{2,3}$";
		//String regex="[a-zA-Z]+";
		String regex="^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";
		return Pattern.matches(regex, emailId);
	}
	/**
	 * @param cutomer
	 * @return true if number is 10-digit   
	 */
	public Boolean isValidPhoneNumber(Long phoneNumber) {
		String regex="^[1-9][0-9]{9}$";
		String mobile=phoneNumber.toString();
		return Pattern.matches(regex, mobile);
	}

}
